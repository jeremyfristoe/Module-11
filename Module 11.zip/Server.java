package m11v3;

import java.io.*;
import java.net.*;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/** 
 * Client/Server is an application which allows the client to send a request to a
 * server to compute whether a number that the user provided is prime.
 * 
 * @author Jeremy Fristoe
 * @version 11.3  December 1, 2020
 */

public class Server extends Application {
	@Override
	// Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Text area for displaying contents
		TextArea ta = new TextArea();
		// Create a scene and place it in the stage
		Scene scene = new Scene(new ScrollPane(ta), 450, 200);
		primaryStage.setTitle("Server"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
		new Thread( () -> {
			try {
				// Create a server socket
				@SuppressWarnings("resource")
				ServerSocket serverSocket = new ServerSocket(8000);
				Platform.runLater(() ->
				ta.appendText("Server started at " + new Date() + '\n'));
				// Listen for a connection request
				Socket socket = serverSocket.accept();
				// Create data input and output streams
				DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
				DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());
				while (true) {
					// Receive number from the client
					int number = inputFromClient.readInt();
					// Determine whether number is prime
					boolean isPrime = true;
					for (int i=2; i<=number/2; i++) {
						if (number%i == 0) {
							isPrime = false;
							break;
						}
					}
					outputToClient.writeBoolean(isPrime);
					Platform.runLater(() -> {
						ta.appendText("Number received from client: " + number + '\n');
					// Send determination back to the client

					});
				}
			}
			catch(IOException ex) {
				ex.printStackTrace();
			}
		}).start();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}

